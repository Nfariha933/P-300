
<?php $__env->startSection('admin_content'); ?>
		
<ul class="breadcrumb">
    <li>
    <i class="icon-home"></i>
    <a href="index.html">Home</a> 
    <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">Dashboard</a></li>
    </ul>

    <h1>Driving Scholl Controll Panel</h1>

                
    </div><!--/row-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Fariha 300\drivingzone\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>