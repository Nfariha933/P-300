@extends('admin_layout')
@section('admin_content')
		
<ul class="breadcrumb">
    <li>
    <i class="icon-home"></i>
    <a href="index.html">Home</a> 
    <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">Dashboard</a></li>
    </ul>

    <h1>Driving Scholl Controll Panel</h1>

                
    </div><!--/row-->



@endsection