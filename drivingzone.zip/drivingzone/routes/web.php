<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\SliderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//-------------------------frontend--------------------------------


Route::get('/',[HomeController::class, 'index']);



//-------------------------beckend--------------------------------

Route::get('/logout',[SuperAdminController::class, 'logout']);
Route::get('/admin',[AdminController::class, 'index']);
Route::get('/dashboard',[AdminController::class, 'show_dashboard']);
Route::post('/admin_dashboard',[AdminController::class, 'dashboard']);


//-----------------------slider rout------------------------------------


Route::get('/add-slider', [SliderController::class, 'index']);
Route::post('/save-slider', [SliderController::class, 'save_slider']);
Route::get('/all-slider', [SliderController::class, 'all_slider']);
Route::get('/unactive_slider/{slider_id}', [SliderController::class, 'unactive_slider']); 
Route::get('/active_slider/{slider_id}', [SliderController::class, 'active_slider']);
Route::get('/delete_slider/{slider_id}', [SliderController::class, 'delete_slider']);
